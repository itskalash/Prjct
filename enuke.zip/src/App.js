
import { useEffect } from 'react';
import { useState } from 'react';
import axios from 'axios';
import './App.css';

const App = () => {

  const [list, setList] = useState({});

  const getData = async () => {
    await axios.get("https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=IBM&interval=5min&apikey=demo").then(
      (resp) => setList(resp.data))
  }

  useEffect(() => {
    getData();
  }, [])

  let dtKeys=[];
  let objDt={};
  if (Object.keys(list).length > 0) {
    objDt = list["Time Series (5min)"]; //2012:20:10 :{open: 65,}
    dtKeys = Object.keys(objDt);
  }


  return (
    <div >
      {

        <table >
          <thead>
            <td>Date Time</td>
            <td>open</td>
            <td>high</td>
            <td>low</td>
            <td>close</td>
            <td>volume</td>
          </thead>
          <tbody>
            {dtKeys.length>0 ? dtKeys.map((key, index) => {
              return (
                <tr key={`${key} + ${index}`}>
                  <td>
                    {key}
                  </td>
                  <td>
                    {objDt[key]["1. open"]}
                  </td>
                  <td>
                    {objDt[key]["2. high"]}
                  </td>
                  <td>
                    {objDt[key]["3. low"]}
                  </td>
                  <td>
                    {objDt[key]["4. close"]}
                  </td>
                  <td>
                    {objDt[key]["5. volume"]}
                  </td>
                </tr>
              )
            }) : <span>No data found</span>}
          </tbody>
        </table>

      }
    </div>
  );
}

export default App;
